using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Controls.Primitives;
using Microsoft.UI.Xaml.Data;
using Microsoft.UI.Xaml.Input;
using Microsoft.UI.Xaml.Media;
using Microsoft.UI.Xaml.Navigation;
using Windows.Foundation;
using Windows.Foundation.Collections;
using System.Net.Http;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq;
using LiveChartsCore.Defaults;
using LiveChartsCore.SkiaSharpView;
using LiveChartsCore;

// To learn more about WinUI, the WinUI project structure,
// and more about our project templates, see: http://aka.ms/winui-project-info.

namespace CurrencyConverter
{
    /// <summary>
    /// An empty window that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainWindow : Window
    {

        private JObject exchangeRates; // ��� ȯ�� �����͸� ����
        private readonly string apiKey = "38917be4333a4e44b92fbb3661626272"; // Open Exchange Rates API Ű
        private readonly string historicalEndpoint = "https://openexchangerates.org/api/historical/";
        public MainWindow()
        {
            this.InitializeComponent();
            _ = LoadExchangeRatesAsync();
        }

        private async Task LoadExchangeRatesAsync()
        {
            string apiKey = "38917be4333a4e44b92fbb3661626272"; // Open Exchange Rates���� �߱޹��� API Ű
            string url = $"https://openexchangerates.org/api/latest.json?app_id={apiKey}";

            try
            {
                using HttpClient client = new HttpClient();
                string response = await client.GetStringAsync(url);

                exchangeRates = JObject.Parse(response);

                var currencies = exchangeRates["rates"].ToObject<Dictionary<string, double>>().Keys;
                BaseCurrencyComboBox.ItemsSource = currencies;
                TargetCurrencyComboBox.ItemsSource = currencies;

                //ExchangeRateText.Text = "ȯ�� �����Ͱ� ���������� �ε�Ǿ����ϴ�.";
            }
            catch (Exception ex)
            {
                //ExchangeRateText.Text = $"ȯ�� �������� ����: {ex.Message}";
            }
        }
        private void OnSwapButtonClick(object sender, RoutedEventArgs e)
        {
            // ��� ��ȭ�� ���� ��ȭ ��ġ ��ȯ
            var temp = BaseCurrencyComboBox.SelectedItem;
            BaseCurrencyComboBox.SelectedItem = TargetCurrencyComboBox.SelectedItem;
            TargetCurrencyComboBox.SelectedItem = temp;
        }
        private void OnCalculateClick(object sender, RoutedEventArgs e)
        {
            if (exchangeRates == null)
            {
                ResultText.Text = "ȯ�� �����͸� ���� ����������.";
                return;
            }
            string baseCurrency = BaseCurrencyComboBox.SelectedItem?.ToString();
            string targetCurrency = TargetCurrencyComboBox.SelectedItem?.ToString();
            if (string.IsNullOrEmpty(baseCurrency) || string.IsNullOrEmpty(targetCurrency))
            {
                ResultText.Text = "��� ��ȭ�� ���� ��ȭ�� �Է��ϼ���.";
                return;
            }
            if (!double.TryParse(AmountInput.Text, out double amount))
            {
                ResultText.Text = "��ȿ�� �ݾ��� �Է��ϼ���.";
                return;
            }

            try
            {
                double baseRate = exchangeRates["rates"][baseCurrency]?.Value<double>() ?? 0;
                double targetRate = exchangeRates["rates"][targetCurrency]?.Value<double>() ?? 0;

                if (baseRate == 0 || targetRate == 0)
                {
                    ResultText.Text = "�������� �ʴ� ��ȭ�Դϴ�.";
                    return;
                }

                // �� ��ȭ �� ȯ�� ���
                double convertedAmount = (amount / baseRate) * targetRate;
                ResultText.Text = $"{convertedAmount:N2} {targetCurrency}";
            }
            catch (Exception ex)
            {
                ResultText.Text = $"��� �� ������ �߻��߽��ϴ�: {ex.Message}";
            }
        }
        private async Task<List<(string date, double rate)>> GetHistoricalRatesAsync(string baseCurrency, string targetCurrency)
        {
            var historicalRates = new List<(string date, double rate)>();
            using HttpClient client = new HttpClient();

            for (int i = 0; i < 12; i++)
            {
                var date = DateTime.UtcNow.AddMonths(-i).ToString("yyyy-MM-01");
                var url = $"{historicalEndpoint}{date}.json?app_id=38917be4333a4e44b92fbb3661626272";

                try
                {
                    var response = await client.GetStringAsync(url);
                    var data = JObject.Parse(response);
                    double baseRate = data["rates"][baseCurrency]?.Value<double>() ?? 0;
                    double targetRate = data["rates"][targetCurrency]?.Value<double>() ?? 0;

                    if (baseRate != 0 && targetRate != 0)
                    {
                        historicalRates.Add((date, targetRate / baseRate));
                    }
                }
                catch (Exception ex)
                {
                    ShowError($"������ �������� ����: {ex.Message}");
                    break;
                }
            }

            historicalRates.Reverse(); // �ֽ� �����Ͱ� ���������� ������ ����
            return historicalRates;
        }

        // �׷����� ������ �ε�
        private async void OnLoadGraphClick(object sender, RoutedEventArgs e)
        {
            string baseCurrency = BaseCurrencyComboBox.SelectedItem?.ToString();
            string targetCurrency = TargetCurrencyComboBox.SelectedItem?.ToString();

            if (string.IsNullOrEmpty(targetCurrency))
            {
                ShowError("��ǥ ��ȭ�� �����ϼ���.");
                return;
            }

            var historicalData = await GetHistoricalRatesAsync(baseCurrency, targetCurrency);
            if (historicalData.Count == 0)
            {
                ShowError("ȯ�� �����͸� �������� ���߽��ϴ�.");
                return;
            }

            // ��Ʈ ������ ����
            var values = new List<DateTimePoint>();
            foreach (var data in historicalData)
            {
                values.Add(new DateTimePoint(DateTime.Parse(data.date), data.rate));
            }
            ExchangeRateChart.Series = new ISeries[]
            {
                new LineSeries<DateTimePoint>
                {
                    Values = values,
                    Name = $"{targetCurrency} / {baseCurrency}"
                }
            };
            ExchangeRateChart.XAxes = new[]
            {
                new Axis
                {
                    Labeler = value => new DateTime((long)value).ToString("MM yyyy"),
                    Name = "Date"
                }
            };
            ExchangeRateChart.YAxes = new[]
            {
                new Axis
                {
                    Labeler = value => $"{value:N2}",
                    Name = "Currency" //��� ��ȭ�� ��ǥ ��ȭ
                }
            };
        }

        // ���� �޽��� ǥ��
        private void ShowError(string message)
        {
            ContentDialog errorDialog = new ContentDialog
            {
                Title = "����",
                Content = message,
                CloseButtonText = "Ȯ��",
                XamlRoot = this.Content.XamlRoot
            };
            _ = errorDialog.ShowAsync();
        }

    }
}
